class AuthType:
    BASIC = (1,)
    DIGEST = (2,)
    UNAUTHORISED = 3
